# MCP Content Analyzer System Design

## Overview

A containerized MCP (Model Context Protocol) server system built with Hono and TypeScript that enables Claude to automatically scrape web content, process screenshots, analyze content against predefined topics, and manage local Excel files.

## System Architecture

### Core Components

1. **Main Hono MCP Server Hub** (`src/index.ts`)
   - Orchestrates multiple MCP servers under single Hono process
   - Provides unified MCP tool endpoint
   - Handles tool routing to appropriate sub-servers

2. **Hono Application Setup** (`src/app.ts`)
   - Sets up Hono server with middleware
   - Configures routes and error handling
   - Provides health check endpoints

3. **MCP Route Handler** (`src/routes/mcp.ts`)
   - Handles MCP tool list and call endpoints
   - Type-safe tool routing
   - Request/response validation

4. **Specialized MCP Servers**
   - **Web Scraper** (`src/servers/web-scraper.ts`): Playwright-based content extraction
   - **Excel Manager** (`src/servers/excel-manager.ts`): ExcelJS-based database operations
   - **Document Reader** (`src/servers/document-reader.ts`): PDF, DOCX, TXT document processing

5. **Base Server** (`src/servers/base-server.ts`)
   - Common MCP server functionality
   - Standardized error handling
   - Response formatting utilities

### Technical Stack

- **Framework**: Hono (ultra-fast web framework)
- **Runtime**: Node.js 18+
- **Language**: TypeScript with strict typing
- **MCP SDK**: @modelcontextprotocol/sdk
- **Web Scraping**: Playwright + Cheerio
- **Excel Operations**: ExcelJS
- **Document Processing**: PDF.js, mammoth (DOCX), fs (TXT)
- **Validation**: Zod schemas
- **Logging**: Winston
- **Containerization**: Docker + Docker Compose

### MCP Tools Provided

#### Content Analysis Workflow
- `analyze_content_workflow`: Complete pipeline (scrape/OCR → analyze → categorize → store)

#### Web Scraping
- `scrape_webpage`: Extract content from URLs
- `check_url_accessibility`: Validate URL before processing

#### Document Processing
- `read_document`: Extract content from PDF, DOCX, TXT files
- `analyze_document_metadata`: Get document properties and structure
- `extract_document_text`: Pure text extraction with formatting preservation

#### Excel Database Operations
- `add_content_entry`: Add new content to Excel database
- `search_similar_content`: Find related existing entries
- `get_topic_categories`: Retrieve available topics
- `get_database_stats`: Return database metrics

#### Image Processing
- User provides screenshots directly to Claude with extracted text
- Claude passes processed text content to MCP tools for analysis

## Detailed Workflow Specifications

### Document Processing Workflow

The document reader server provides comprehensive document processing capabilities as a fallback when web content is inaccessible or when direct document analysis is needed.

#### Supported Document Formats

1. **PDF Documents**
   - Text extraction using PDF.js (Mozilla's PDF rendering library)
   - Metadata extraction (title, author, creation date, keywords)
   - Page-by-page processing for large documents
   - Handles both text-based and scanned PDFs
   - OCR fallback for image-based PDFs

2. **Microsoft Word Documents (DOCX)**
   - Content extraction using mammoth.js
   - Preserves basic formatting (headings, paragraphs, lists)
   - Metadata extraction (author, title, creation date, modification date)
   - Embedded image handling
   - Comment and revision extraction

3. **Plain Text Documents (TXT, RTF)**
   - Direct file system reading
   - Encoding detection and conversion
   - Line-by-line processing for large files
   - Basic metadata (file size, dates, encoding)

4. **Rich Text Format (RTF)**
   - Text extraction with basic formatting preservation
   - Metadata extraction
   - Image placeholder identification

#### Document Processing Pipeline

1. **Format Detection**
   - MIME type analysis
   - File extension validation
   - Content sniffing for corrupted extensions
   - Security validation (file size limits, malware scanning)

2. **Content Extraction**
   - Format-specific parsing
   - Text content extraction
   - Metadata collection
   - Structure analysis (headings, sections, pages)

3. **Content Processing**
   - Text cleaning and normalization
   - Summary generation
   - Key point extraction
   - Language detection

4. **Integration with Excel Database**
   - Document-to-content-entry conversion
   - Automatic topic categorization
   - Duplicate detection
   - Metadata preservation

#### Error Handling and Fallbacks

- **Corrupted Documents**: Partial content extraction with error reporting
- **Password-Protected Files**: Error handling with guidance for user
- **Large Files**: Streaming processing and content truncation
- **Unsupported Formats**: Clear error messages with format suggestions
- **Claude Vision Integration**: For image-based content, user shares screenshot with Claude for text extraction

### Enhanced Content Analysis Workflow

With document processing capabilities, the complete content analysis workflow becomes:

1. **Input Assessment**
   - URL accessibility check
   - Document format detection
   - Processing method selection

2. **Content Extraction** (Multiple Sources)
   - Web scraping (for accessible URLs)
   - Document reading (for files or inaccessible URLs)
   - Image text extraction (Claude's native vision capabilities)

3. **Content Analysis**
   - Text summarization
   - Key point extraction
   - Topic categorization
   - Metadata enrichment

4. **Database Integration**
   - Excel entry creation
   - Duplicate detection
   - Categorization
   - Indexing for search

5. **Workflow Tool**: `analyze_content_workflow`
   ```
   Input: URL, document path, or Claude-extracted text from images
   Process:
     - Try web scraping first (for URLs)
     - Fallback to document reading if URL fails
     - Accept pre-processed text from Claude's image analysis
     - Analyze and categorize content
     - Save to Excel database
   Output: Complete analysis results with source information
   ```

## Project Structure

```
mcp-content-analyzer/
├── package.json                    # Dependencies and scripts
├── tsconfig.json                   # TypeScript configuration
├── Dockerfile                      # Multi-stage Docker build
├── docker-compose.yml              # Container orchestration
├── .env.template                   # Environment template
├── .gitignore                      # Git ignore patterns
├── src/
│   ├── index.ts                    # Main MCP server entry point
│   ├── app.ts                      # Hono application setup
│   ├── routes/
│   │   ├── mcp.ts                  # MCP tool routes
│   │   ├── health.ts               # Health check routes
│   │   └── index.ts                # Route exports
│   ├── servers/
│   │   ├── base-server.ts          # Base MCP server class
│   │   ├── web-scraper.ts          # Web scraping server
│   │   ├── excel-manager.ts        # Excel operations server
│   │   └── document-reader.ts      # Document processing server
│   ├── middleware/
│   │   ├── logger.ts               # Request logging
│   │   ├── error-handler.ts        # Error handling
│   │   └── auth.ts                 # Authentication
│   ├── utils/
│   │   ├── config.ts               # Configuration management
│   │   ├── logger.ts               # Winston logger setup
│   │   └── validators.ts           # Zod validation schemas
│   ├── types/
│   │   ├── mcp.ts                  # MCP tool types
│   │   ├── content.ts              # Content analysis types
│   │   └── index.ts                # Type exports
│   └── templates/
│       └── claude-config.json      # Claude Desktop config template
├── scripts/
│   ├── setup.sh                    # Initial setup script
│   ├── test-connection.sh          # Connection testing
│   ├── generate-config.sh          # Claude config generator
│   └── docker-deploy.sh            # Docker deployment
├── config/
│   ├── topics-template.json        # Default topic categories
│   └── excel-schema.json           # Excel file structure
├── data/
│   └── content-database.xlsx       # Main Excel database (git-ignored)
├── docs/
│   ├── SETUP.md                    # Setup instructions
│   ├── USAGE.md                    # Usage examples
│   ├── API.md                      # MCP tool specifications
│   └── TROUBLESHOOTING.md          # Common issues
└── tests/
    ├── unit/
    └── integration/
```

## Key Design Decisions

### 1. Hono Framework Choice
- Ultra-fast performance with Web Standards
- Type-safe routing and middleware
- Excellent TypeScript support
- Minimal overhead for MCP server operations

### 2. Local Excel Storage
- No cloud dependencies or costs
- Direct file manipulation with ExcelJS
- Team-shareable files via network drives
- Automatic backup and versioning

### 3. Modular MCP Server Architecture
- Each functionality as separate server class
- Common base class for shared functionality
- Clear separation of concerns
- Easy to test and extend

### 4. Multi-Stage Docker Build
- Optimized for production deployment
- Separate stages for dependencies, compilation, and runtime
- Includes Playwright browser installation
- Health checks and proper user permissions

### 5. TypeScript-First Development
- Strict typing throughout
- Compile-time error catching
- Better IDE support and refactoring
- Runtime type validation with Zod

### 6. Document Processing Strategy
- Multi-format support (PDF, DOCX, TXT, RTF)
- Metadata extraction and preservation
- Text formatting preservation where possible
- Fallback handling for corrupted/protected documents
- Memory-efficient streaming for large files

## Environment Configuration

### Required Variables
```bash
EXCEL_DATABASE_PATH=./data/content-database.xlsx
GOOGLE_VISION_API_KEY=your_api_key
MCP_SERVER_PORT=3000
TEAM_NAME=your_team
```

### Optional Features
- Excel backup system
- OCR fallback to Tesseract
- Rate limiting for web scraping
- Redis caching for team deployments

## Security Considerations

1. **Credential Management**: Service account keys in secure volumes
2. **Network Security**: Internal network isolation, rate limiting
3. **Data Privacy**: Local file storage, PII detection
4. **Access Control**: Team-based configurations

## Testing Strategy

1. **Unit Tests**: Individual server components
2. **Integration Tests**: Full workflow testing
3. **Connection Tests**: MCP server communication
4. **Health Checks**: Docker container monitoring

## Documentation Requirements

1. **Setup Guide**: Installation and configuration
2. **Usage Examples**: Common Claude interactions
3. **API Reference**: MCP tool specifications
4. **Troubleshooting**: Common issues and solutions

## Performance Targets

- Tool response time: < 5 seconds for web scraping
- Document processing: < 3 seconds for small files (< 1MB), < 10 seconds for large files
- Image text processing: Handled by Claude's native capabilities (no additional processing time)
- Excel operations: < 1 second for database queries
- Memory usage: < 512MB base, < 1GB with browsers, < 200MB additional per large document

## Deployment Options

1. **Local Development**: Direct Node.js execution
2. **Docker Single**: Container with all services
3. **Team Deployment**: Docker Compose with shared volumes
4. **Production**: Multi-instance with load balancing