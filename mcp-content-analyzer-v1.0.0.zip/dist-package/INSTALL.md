# 🚀 MCP Content Analyzer - Team Installation

## Quick Install (2 minutes)

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Install globally:**
   ```bash
   npm install -g .
   ```

3. **Setup and configure:**
   ```bash
   mcp-content-analyzer setup
   mcp-content-analyzer config
   ```

4. **Restart Claude Desktop completely**

5. **Start the analyzer:**
   ```bash
   mcp-content-analyzer start
   ```

## Test Installation
```bash
mcp-content-analyzer test
```

## Available Commands
- `mcp-content-analyzer start` - Start the server
- `mcp-content-analyzer test` - Test connection
- `mcp-content-analyzer help` - Show all commands

## Support
Contact team lead if you have issues!
